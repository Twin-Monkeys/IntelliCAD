#pragma once

class UpdateSlicingPointFromViewListener
{
public:
	virtual void onUpdateSlicingPointFromView() = 0;
};