#pragma once

enum class StreamAnchorType
{
	BEGINNING,
	CURRENT,
	END
};
