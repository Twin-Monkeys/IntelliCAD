#pragma once

#include "Vector2D.h"

using Point2D = Vector2D;
