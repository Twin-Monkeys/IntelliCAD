#pragma once

#include "tstring.h"
#include "VolumeNumericMeta.h"

class VolumeMeta
{
public:
	std::tstring fileName;
	VolumeNumericMeta numeric;
};