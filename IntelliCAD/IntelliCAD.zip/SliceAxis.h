#pragma once

enum SliceAxis
{
	TOP,
	FRONT,
	RIGHT
};