#pragma once

enum ColorChannelType
{
	RED,
	GREEN,
	BLUE,
	ALPHA,
	ALL
};
