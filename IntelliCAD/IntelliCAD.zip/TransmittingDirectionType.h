#pragma once

enum class TransmittingDirectionType
{
	UP,
	DOWN
};