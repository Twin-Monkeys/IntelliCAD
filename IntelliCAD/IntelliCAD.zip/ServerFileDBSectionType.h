#pragma once

enum class ServerFileDBSectionType
{
	CT_IMAGE
};
