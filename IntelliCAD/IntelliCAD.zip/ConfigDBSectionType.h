#pragma once

enum class ConfigDBSectionType
{
	CLIENT_NETWORK
};