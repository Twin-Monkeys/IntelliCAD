#pragma once

class InitLightListener
{
public:
	virtual void onInitLight() = 0;
};