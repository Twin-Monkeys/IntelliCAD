#pragma once

class LesionAnalyzer
{
public:

};
