#pragma once

enum class RenderingScreenType
{
	SLICE_TOP,
	SLICE_FRONT,
	SLICE_RIGHT,
	VOLUME_RENDERING
};
