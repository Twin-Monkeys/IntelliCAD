#pragma once

#include "EventBroadcaster.h"

namespace SystemIndirectAccessor
{
	EventBroadcaster &getEventBroadcaster();
}