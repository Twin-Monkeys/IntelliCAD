#pragma once

#include "Vector3D.h"

using Point3D = Vector3D;