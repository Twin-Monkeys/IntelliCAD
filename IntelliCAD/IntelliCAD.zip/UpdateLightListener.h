#pragma once

class UpdateLightListener
{
public:
	virtual void onUpdateLight() = 0;
};