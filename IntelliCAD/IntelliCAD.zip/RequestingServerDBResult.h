#pragma once

enum class RequestingServerDBResult
{
	NOT_AUTHORIZED,
	CONNECTION_ERROR,
	NON_EXISTENT,
	SUCCESS
};