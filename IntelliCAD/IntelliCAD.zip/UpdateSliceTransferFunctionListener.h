#pragma once

class UpdateSliceTransferFunctionListener
{
public:
	virtual void onUpdateSliceTransferFunction() = 0;
};