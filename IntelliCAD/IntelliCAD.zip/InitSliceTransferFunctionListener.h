#pragma once

class InitSliceTransferFunctionListener
{
public:
	virtual void onInitSliceTransferFunction() = 0;
};